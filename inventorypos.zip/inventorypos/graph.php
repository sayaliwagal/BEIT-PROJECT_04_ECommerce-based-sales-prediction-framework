<?php

    include_once'header.php'

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Admin Dashboard) -->
    <section class="content-header">
      <h1>
       Sales Report ->Table Report 
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

      <!--------------------------
        | Your Page Content Here |
        -------------------------->

   
    <div class="box box-warning">
             <form action="" method="post" name="">
            <div class="box-header with-border">
              <h3 class="box-title">blank</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
      
           
            <div class="box-body">
                
        <div class="row">
            
        <div class="col-md-5">
            
            <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" id="datepicker1" name="date_1" date-date-format="yyyy-mm-dd" >
                </div>
            </div>
         
            
                <div class="col-md-5">
                 
                 <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" id="datepicker2" name="date_2" date-date-format="yyyy-mm-dd" >
                </div>
                  
                    
                </div>

       
               <div class="col-md-2">
                   
                    <div align="left">
                <input type="submit" name="btndatefilter" value="Filter By Date"  class="btn btn-success">
                      </div>
               </div>

        </div>
              <br>
              <br>
               
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-files-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Invoice</span>
              <span class="info-box-number">32</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
    

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-inr"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Sub Total</span>
              <span class="info-box-number">72569</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-inr"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Net Total</span>
              <span class="info-box-number">69569</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
                
           <br>
                  <table id="SalesReportTable" class="table table-striped">
                  <thead>
                  <tr>
                    <th>Invoice ID</th>
                    <th>Customer Name</th>
                    <th>Subtotal</th>
                        <th>Tax</th>
                            <th>Discount</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Due</th>
                            <th>Payment Type</th>
                            <th>Order Date</th>
                  </tr>
                  </thead>
                  
                  
                  
                  <tbody>
                          <tr>
                    <td>3101</td>
                    <td>Viraj Gore</td>
                    <td>2650</td>
                    <td>132.5</td>
                    <td>0</td>
                    <td>2782.5</td>
                    <td>3000</td>
                    <td>217.5</td>
                    <td>Cash</td>
                     <td>20-08-2019</td>
                  </tr>
                  <tr>
                    <td>3102</td>
                    <td>Kataki Kolhe</td>
                    <td>750</td>
                    <td>47.5</td>
                     <td>0</td>
                    <td>787.5</td>
                    <td>800</td>
                    <td>12.5</td>
                    <td>Card</td>
                     <td>02-05-2019</td>
                    
                  </tr>
                  <tr>
                    <td>3103</td>
                    <td>Sudhir More</td>
                    <td>11550</td>
                    <td>577.5</td>
                    <td>200</td>
                    <td>11927.5</td>
                    <td>12000</td>
                    <td>12.5</td>
                    <td>Card</td>
                    <td>08-06-2019</td>
                  </tr>
                  <tr>
                    <td>3104</td>
                    <td>Jayesh Sonar</td>
                    <td>7500</td>
                    <td>375</td>
                    <td>0</td>
                    <td>7875</td>
                    <td>8000</td>
                    <td>125</td>
                    <td>Cash</td>
                     <td>05-11-2019</td>
                  </tr>
                  <tr>
                    <td>3105</td>
                    <td>Kajal Patil</td>
                    <td>700</td>
                    <td>35</td>
                    <td>0</td>
                    <td>735</td>
                    <td>735</td>
                    <td>0</td>
                    <td>Check</td>
                     <td>21-10-2019</td>
                  </tr>
                  <tr>
                    <td>3106</td>
                    <td>Shivam Wagamare</td>
                    <td>1900</td>
                    <td>25</td>
                    <td>0</td>
                    <td>1995</td>
                    <td>2000</td>
                    <td>5</td>
                    <td>Cash</td>
                     <td>15-10-2019</td>
                  </tr>                 
              
                  
                
                  </tbody>
                </table>     
                
            
    
                 </div>
            
        </form>
              
                  
               </div>
                
                
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
<script>

   //Date picker
    $('#datepicker1').datepicker({
      autoclose: true
    })
    
    
     //Date picker
    $('#datepicker2').datepicker({
      autoclose: true
    })
    
    

</script>

<?php

    include_once'footer.php';

?>